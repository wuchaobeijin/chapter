package org.jfinal.controller;

import org.jfinal.model.Message;

import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Page;
import com.jfinal.plugin.activerecord.Record;



public class MessageController extends Controller{

	public void index() {
		setAttr("messages", Message.dao.paginate(getParaToInt(0, 1), 10));
		render("getMessage.jsp");
	}
	
	public void submit(){
	    String userId = getPara("userId");
		String title = getPara("title");
		
		String context = getPara("context");
		Record message = new Record().set("userId", userId)  //将得到的值传到数据库中
				                     .set("title", title)
				                     .set("context",context);
		Db.save("message", message);  //前面一个是表名,后面一个是对应的record生成的名字
		redirect("/message");
	}
	
	public void edit() {
		int messageId = getParaToInt();
		setSessionAttr("messageId", messageId);
		render("_add.jsp");	
		}
	
	
	public void update() {
		    String title = getPara("title");
			String context = getPara("context");
			Message.dao.findById(getParaToInt()).set("title", title)
			                                   .set("context", context).update();
			redirect("/message");
		}
	
	public void delete() {
	  Db.deleteById("message", "messageId", getParaToInt()); //第一个为表名,第二个是表的id,第三个是删除传过来的id
		//Message.dao.deleteById(getParaToInt());
		redirect("/message");             //回到message动作下的index方法
	}
	public void search(){
		String ww=getPara("ww");
		Page<Record> messages = Db.paginate(1, 5, "select *"," from message where context = ?",ww);
		setAttr("messages", messages);
		render("getMessage.jsp");
	}
}
