package org.jfinal.controller;

import org.jfinal.interceptor.LoginValidator;

import com.jfinal.aop.Before;
import com.jfinal.aop.Clear;
import com.jfinal.core.Controller;

public class IndexController extends Controller {
    	
	public void index() {
		render("index.jsp");
	}
}
