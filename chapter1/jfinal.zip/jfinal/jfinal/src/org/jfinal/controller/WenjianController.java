package org.jfinal.controller;

//import java.text.SimpleDateFormat;
//import java.util.Date;

import org.jfinal.model.Wenjian;

import com.jfinal.core.Controller;
import com.jfinal.plugin.activerecord.Db;
import com.jfinal.plugin.activerecord.Record;
import com.jfinal.upload.UploadFile;


public class WenjianController  extends Controller{
	public void index() {
		setAttr("wenjians", Wenjian.dao.paginate(getParaToInt(0, 1), 10));
		render("getFile.jsp");
	}
	public void upload() {
		//String path = new SimpleDateFormat("yyyy/MM/dd").format(new Date());
		UploadFile file = getFile("file");
		String fileName = file.getFileName();
		Long length =file.getFile().length();
		String lujing = file.getSaveDirectory();
		
	lujing=lujing.substring(54);       //取子字符串54位之后的
		lujing=lujing+fileName;
		
		String lujing2 = file.getFile().getPath();
		Record upload = new Record().set("fileName", fileName)  //将得到的值传到数据库中
                                   .set("length", length)
                                   .set("lujing2", lujing2)
		                           .set("lujing", lujing);
            Db.save("wenjian", upload);  //前面一个是表名,后面一个是对应的record生成的名字
            redirect("/wenjian");
			
			
		}
	public void xiazai() {
		
		}	
}	
