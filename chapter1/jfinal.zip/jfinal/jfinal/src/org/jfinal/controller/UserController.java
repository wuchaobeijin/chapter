package org.jfinal.controller;

import org.jfinal.interceptor.LalaInterceptor;
import org.jfinal.interceptor.LoginValidator;
import org.jfinal.model.User;

import com.jfinal.aop.Before;
import com.jfinal.aop.Clear;
import com.jfinal.core.Controller;

public class UserController  extends Controller{
	


	public void login(){
		String username = getPara("username");
		String password = getPara("password");
		System.out.println("1111");
		User user = User.dao.checklogin(username,password);
		System.out.println(username+password);
		if(user!=null){
			setSessionAttr("userId",user.get("userId"));
			setSessionAttr("username",user.get("username"));
			redirect("/message");
		}
		else{
			render("error.jsp");
		}
	}
	@Clear(LalaInterceptor.class)
	public void lala(){
	}

}
