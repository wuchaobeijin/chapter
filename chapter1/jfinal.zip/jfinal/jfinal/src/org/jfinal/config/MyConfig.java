package org.jfinal.config;

import java.io.File;

import org.jfinal.controller.IndexController;
import org.jfinal.controller.MessageController;
import org.jfinal.controller.UserController;
import org.jfinal.controller.WenjianController;
import org.jfinal.handle.QqHandle;
import org.jfinal.interceptor.LoginValidator;
import org.jfinal.model.Message;
import org.jfinal.model.User;
import org.jfinal.model.Wenjian;

import com.jfinal.config.Constants;
import com.jfinal.config.Handlers;
import com.jfinal.config.Interceptors;
import com.jfinal.config.JFinalConfig;
import com.jfinal.config.Plugins;
import com.jfinal.config.Routes;
import com.jfinal.core.JFinal;
import com.jfinal.kit.PropKit;
import com.jfinal.plugin.activerecord.ActiveRecordPlugin;
import com.jfinal.plugin.c3p0.C3p0Plugin;
import com.jfinal.render.ViewType;

public class MyConfig extends JFinalConfig {
	
	public void configConstant(Constants me) {
		PropKit.use("a_little_config.txt");		
		me.setError404View("/page/user/error.jsp");//如果程序出现错误指向这个错误页面ֵ
		me.setDevMode(PropKit.getBoolean("devMode", false));//设置开发模式
		me.setViewType(ViewType.JSP); 	
	    me.setUploadedFileSaveDirectory(File.separator+ "upload" + File.separator);
		// 设定文件保存 位置。默认是项目下的upload，因为项目是部署在D盘下的一个目录下的，所以这将在D盘下。
		//保存在固定文件夹下-> me.setUploadedFileSaveDirectory("C:" + File.separator+ "uploadFiles" + File.separator);//定义页面为jsp格式				
	}
	
	
	public void configRoute(Routes me) {
		me.add("/", IndexController.class, "/page/index");	
		me.add("/user", UserController.class,"/page/user");		//将含有这个"/user"的action指向"UserController.class类"来处理,	处理完之后所指向的页面是"/page/user"下的jsp页面
		me.add("/message", MessageController.class,"/page/message");
		me.add("/wenjian",WenjianController.class,"/page/upload");
	}
	
	
	public void configPlugin(Plugins me) {
		C3p0Plugin c3p0Plugin = new C3p0Plugin(PropKit.get("jdbcUrl"), PropKit.get("user"), PropKit.get("password").trim());
		//C3p0Plugin cp = new C3p0Plugin("jdbc:mysql://localhost:3306/test",
	   //	"root", "123456");
		me.add(c3p0Plugin);
			
		ActiveRecordPlugin arp = new ActiveRecordPlugin(c3p0Plugin);
		me.add(arp);
		arp.addMapping("user", "userId",User.class);	//映射表user和User类关系一一对应
		arp.addMapping("message","messageId", Message.class);
		arp.addMapping("wenjian", Wenjian.class);
		//以上代码中 arp.addMapping(“user”, User.class)，表的主键名为默认为“id”，如果主
		//键名称为 “ user_id”则需要手动指定，如： arp.addMapping(“user”, “user_id”, User.class)。
	}
	

	public void configInterceptor(Interceptors me) {
	//	me.add(new LoginValidator());//全局拦截器;
	}

	public void configHandler(Handlers me) {
		me.add(new QqHandle());
	}
	
	public void afterJFinalStart()
	{
		System.out.println("我");
	} 
	//JFinal 会在系统启动完成后回调 afterJFinalStart()方法， 会在系统 关闭前回 调
	//beforeJFinalStop()方法。 这两个方法可以很方便地在项目启动后与关闭前让开发者有机会进行
	//额外操作，如在系统启动后创建调度线程或在系统关闭前写回缓存。
	public void beforeJFinalStart()
	{
		System.out.println("222");
	}
	
	
	public static void main(String[] args) {
		JFinal.start("WebRoot", 1000, "/", 5);
	}
}
