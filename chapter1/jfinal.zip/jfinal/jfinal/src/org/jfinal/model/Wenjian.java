package org.jfinal.model;

import com.jfinal.plugin.activerecord.Model;
import com.jfinal.plugin.activerecord.Page;

public class Wenjian extends Model<Wenjian> {

	private static final long serialVersionUID = 1L;
	public static final Wenjian dao = new Wenjian();
	public Page<Wenjian> paginate(int pageNumber, int pageSize) {
		return paginate(pageNumber, pageSize, "select *", "from wenjian order by id asc");
	}
	}
