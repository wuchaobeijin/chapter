package org.jfinal.model;

import com.jfinal.plugin.activerecord.Model;

public class User extends Model<User> {
	
	private static final long serialVersionUID = 1L;
	public static final User dao = new User();

	public User checklogin(String username,String password){
		String sql = "SELECT * FROM user WHERE username =? and password =?";
		return dao.findFirst(sql,username,password);
	}
}
