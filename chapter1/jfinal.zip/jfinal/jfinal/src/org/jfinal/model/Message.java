package org.jfinal.model;

import com.jfinal.plugin.activerecord.Model;
import com.jfinal.plugin.activerecord.Page;

public class Message extends Model<Message> {

	private static final long serialVersionUID = 1L;
	public static final Message dao = new Message();
	public Page<Message> paginate(int pageNumber, int pageSize) {
		return paginate(pageNumber, pageSize, "select *", "from message order by messageId asc");
	}
}
