/*
Navicat MySQL Data Transfer

Source Server         : liu
Source Server Version : 50528
Source Host           : localhost:3306
Source Database       : jfinal

Target Server Type    : MYSQL
Target Server Version : 50528
File Encoding         : 65001

Date: 2015-11-14 20:54:30
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `message`
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `messageId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `context` varchar(255) NOT NULL,
  PRIMARY KEY (`messageId`),
  KEY `MESSAGE_TO_USER` (`userId`),
  CONSTRAINT `MESSAGE_TO_USER` FOREIGN KEY (`userId`) REFERENCES `user` (`userId`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('17', '1', 'qq', '去');
INSERT INTO `message` VALUES ('18', '1', '去', '的');
INSERT INTO `message` VALUES ('19', '1', '人', '人');
INSERT INTO `message` VALUES ('20', '1', '人', '人');
INSERT INTO `message` VALUES ('21', '1', '的', '的');
INSERT INTO `message` VALUES ('22', '1', '恶女', '飞');
INSERT INTO `message` VALUES ('23', '1', '的', '的');
INSERT INTO `message` VALUES ('24', '1', '个', '个');
INSERT INTO `message` VALUES ('25', '1', '的', '的');
INSERT INTO `message` VALUES ('26', '1', '的', ' 的');
INSERT INTO `message` VALUES ('27', '1', '人v', '人');
INSERT INTO `message` VALUES ('28', '1', '的', '的');
INSERT INTO `message` VALUES ('29', '1', '的', '的');
INSERT INTO `message` VALUES ('30', '1', '的', '飞');
INSERT INTO `message` VALUES ('31', '1', '的', '飞');
INSERT INTO `message` VALUES ('32', '1', '飞', '发给');
INSERT INTO `message` VALUES ('33', '1', '的', '的');
INSERT INTO `message` VALUES ('34', '1', '是', '的');
INSERT INTO `message` VALUES ('35', '1', '3', '3');
INSERT INTO `message` VALUES ('36', '1', 'e', 'e');
INSERT INTO `message` VALUES ('37', '1', 'd', 'd');
INSERT INTO `message` VALUES ('38', '1', '1', '1');
INSERT INTO `message` VALUES ('39', '1', 's', 's');
INSERT INTO `message` VALUES ('40', '1', 'ty', 't');
INSERT INTO `message` VALUES ('41', '1', ' ', ' ');
INSERT INTO `message` VALUES ('42', '1', '额', '额');
INSERT INTO `message` VALUES ('43', '1', '1', '1');
INSERT INTO `message` VALUES ('44', '1', '1', '1');
INSERT INTO `message` VALUES ('45', '1', '1', '1');
INSERT INTO `message` VALUES ('46', '1', '1', '1');
INSERT INTO `message` VALUES ('47', '1', '2', '2');
INSERT INTO `message` VALUES ('48', '1', '1', '1');
INSERT INTO `message` VALUES ('49', '1', '1', '11');
INSERT INTO `message` VALUES ('50', '1', '1', '1');
INSERT INTO `message` VALUES ('51', '1', '1', '1');
INSERT INTO `message` VALUES ('52', '1', '1', '1');
INSERT INTO `message` VALUES ('53', '1', '1', '1');
INSERT INTO `message` VALUES ('54', '1', '1', '1');
INSERT INTO `message` VALUES ('55', '1', '1', '1');
INSERT INTO `message` VALUES ('56', '1', '1', '1');
INSERT INTO `message` VALUES ('57', '1', '1', '1');
INSERT INTO `message` VALUES ('58', '1', '1', '1');
INSERT INTO `message` VALUES ('59', '1', '1', '1');
INSERT INTO `message` VALUES ('60', '1', '1', '1');
INSERT INTO `message` VALUES ('61', '1', '1', '1');
INSERT INTO `message` VALUES ('62', '1', '1', '1');
INSERT INTO `message` VALUES ('63', '1', '1', '1');
INSERT INTO `message` VALUES ('64', '1', '1', '1');
INSERT INTO `message` VALUES ('65', '1', '1', '1');
INSERT INTO `message` VALUES ('66', '1', '111', '11');
INSERT INTO `message` VALUES ('67', '1', '1', '1');
INSERT INTO `message` VALUES ('68', '1', '1', '1');
INSERT INTO `message` VALUES ('69', '1', '1', '1');
INSERT INTO `message` VALUES ('70', '1', '1', '1');
INSERT INTO `message` VALUES ('71', '1', '2', '2');
INSERT INTO `message` VALUES ('72', '1', '2', '2');
INSERT INTO `message` VALUES ('73', '1', '1', '1');
INSERT INTO `message` VALUES ('74', '1', 'wd', 'dd');
INSERT INTO `message` VALUES ('75', '1', '122', '1');
INSERT INTO `message` VALUES ('76', '1', '22', '22');
INSERT INTO `message` VALUES ('77', '1', '1', '1');
INSERT INTO `message` VALUES ('78', '1', '2', '2');
INSERT INTO `message` VALUES ('79', '1', '2', '2');
INSERT INTO `message` VALUES ('80', '1', '3333', '33');
INSERT INTO `message` VALUES ('81', '1', '2', '2');
INSERT INTO `message` VALUES ('82', '1', '1', '1');
INSERT INTO `message` VALUES ('83', '1', '1', '1');
INSERT INTO `message` VALUES ('84', '1', '上', '');
INSERT INTO `message` VALUES ('85', '1', '是', '是');
INSERT INTO `message` VALUES ('86', '1', '的', '的');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', '1', '1');

-- ----------------------------
-- Table structure for `wenjian`
-- ----------------------------
DROP TABLE IF EXISTS `wenjian`;
CREATE TABLE `wenjian` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fileName` varchar(255) NOT NULL,
  `length` varchar(255) NOT NULL,
  `lujing` varchar(255) NOT NULL,
  `lujing2` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wenjian
-- ----------------------------
INSERT INTO `wenjian` VALUES ('2', '2015/11/085.jpg', '104236', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\\\upload\\', '');
INSERT INTO `wenjian` VALUES ('19', '2015/11/0838.jpg', '141070', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\\\/upload\\', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\38.jpg');
INSERT INTO `wenjian` VALUES ('21', '2015/11/08310.jpg', '141070', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\\\upload\\', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\310.jpg');
INSERT INTO `wenjian` VALUES ('24', '2015/11/08313.jpg', '141070', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\313.jpg');
INSERT INTO `wenjian` VALUES ('25', '2015/11/08314.jpg', '141070', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\314.jpg');
INSERT INTO `wenjian` VALUES ('28', '317.jpg', '141070', 'upload\\', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\317.jpg');
INSERT INTO `wenjian` VALUES ('29', '318.jpg', '141070', 'upload\\318.jpg', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\318.jpg');
INSERT INTO `wenjian` VALUES ('30', '319.jpg', '141070', 'upload\\319.jpg', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\319.jpg');
INSERT INTO `wenjian` VALUES ('31', '320.jpg', '141070', 'upload\\320.jpg', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\320.jpg');
INSERT INTO `wenjian` VALUES ('32', '321.jpg', '141070', 'upload\\321.jpg', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\321.jpg');
INSERT INTO `wenjian` VALUES ('33', '6.jpg', '43471', 'upload\\6.jpg', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\6.jpg');
INSERT INTO `wenjian` VALUES ('34', '27.jpg', '272108', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\\\upload\\', 'F:\\MyEclipse 2015\\.metadata\\.me_tcat7\\webapps\\jfinal\\upload\\27.jpg');
